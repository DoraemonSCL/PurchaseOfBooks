package com.shenlongandwangpengfei.purchaseofbooks.controller;

import com.shenlongandwangpengfei.purchaseofbooks.entity.Student;
import com.shenlongandwangpengfei.purchaseofbooks.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

/**** imports ****/
@Controller
@RequestMapping("/purchaseofbooks")
public class StudentController {

    @Autowired
    private StudentService studentService = null;

    @RequestMapping("/student")
    public ModelAndView details(Long id){
        Student student = studentService.getStudent(id);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("student");
        mv.addObject("student", student);
        System.out.println(">>>>>>>>>>>>>>>>>>>>>"+mv+"????????????????????"+student.getUserName());
        return  mv ;
    }
//    @ResponseBody
//    Student getStudent(Long id){
//        return studentService.getStudent(id);
//    }
}

