package com.shenlongandwangpengfei.purchaseofbooks.entity;

public class StudentBook {
    private String studentId ;
    private String bookId;
    private String studentBookData ;

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getBookId() {
        return bookId;
    }

    public void setStudentBookData(String studentBookData) {
        this.studentBookData = studentBookData;
    }

    public String getStudentBookData() {
        return studentBookData;
    }
}
