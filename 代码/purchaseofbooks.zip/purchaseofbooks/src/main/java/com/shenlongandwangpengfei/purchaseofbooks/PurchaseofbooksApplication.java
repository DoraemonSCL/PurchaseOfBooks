package com.shenlongandwangpengfei.purchaseofbooks;

import org.mybatis.spring.annotation.MapperScan;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Repository;

@SpringBootApplication
@MapperScan(
        //指定扫描包
        basePackages = "com.shenlongandwangpengfei.purchaseofbooks",
        //指定SqlSessionFactory，如果sqlSessionTemplate被指定，则作废
        sqlSessionFactoryRef = "sqlSessionFactory",
        //指定sqlSessionTemplate，将忽略sqlSessionFactory的配置
        sqlSessionTemplateRef = "sqlSessionTemplate",
        //markerInterface = Class.class,//限定扫描接口，不常用
        annotationClass = Repository.class)
public class PurchaseofbooksApplication {

//    @Bean
//    public MapperScannerConfigurer mapperScannerConfig() {
//        //定义扫描器实例
//        MapperScannerConfigurer mapperScannerConfigurer = new MapperScannerConfigurer();
//        //加载SqlSessionFactory,Spring Boot会自动生产，SqlSessionFactory实例，无需我们敢于
//        mapperScannerConfigurer.setSqlSessionFactoryBeanName("sqlSessionFactory");
//        //定义扫描的包
//        mapperScannerConfigurer.setBasePackage("com.shenlongandwangpengfei.purchaseofbooks.*");
//        //限定被标注@Repository的接口才被扫描
//        mapperScannerConfigurer.setAnnotationClass(Repository.class);
//        //通过继承某个接口限制扫描，一般使用不多
//        //mapperScannerConfigurer.setMarkerInterface(。。。。。。);
//        return mapperScannerConfigurer;
//    }

    public static void main(String[] args) {
        SpringApplication.run(PurchaseofbooksApplication.class, args);
    }

}
