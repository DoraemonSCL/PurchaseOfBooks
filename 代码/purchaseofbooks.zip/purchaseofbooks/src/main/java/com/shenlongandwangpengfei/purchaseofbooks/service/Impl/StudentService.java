package com.shenlongandwangpengfei.purchaseofbooks.service.Impl;

import com.shenlongandwangpengfei.purchaseofbooks.entity.Student;

public interface StudentService {
    Student getStudent(Long id);
}
