package com.shenlongandwangpengfei.purchaseofbooks.dao;

import com.shenlongandwangpengfei.purchaseofbooks.entity.Book;
import org.springframework.stereotype.Repository;

@Repository
public interface BookDao {
    public Book getBook();
}
