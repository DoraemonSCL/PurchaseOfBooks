package com.shenlongandwangpengfei.purchaseofbooks.dao;

public interface TeacherBookDao {
}
