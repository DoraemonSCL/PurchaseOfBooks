package com.shenlongandwangpengfei.purchaseofbooks.dao;

import com.shenlongandwangpengfei.purchaseofbooks.entity.Student;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentDao {
    public Student getStudent(Long id);
}
