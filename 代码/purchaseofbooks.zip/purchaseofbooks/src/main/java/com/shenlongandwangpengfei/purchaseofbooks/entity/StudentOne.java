package com.shenlongandwangpengfei.purchaseofbooks.entity;

public class StudentOne {
    private String studentId ;
    private String studentName;
    private String studentSex ;
    private String studentAge;
    private String studentClass;
    private String studentPay ;

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentSex(String studentSex) {
        this.studentSex = studentSex;
    }

    public String getStudentSex() {
        return studentSex;
    }

    public String getStudentAge() {
        return studentAge;
    }

    public void setStudentAge(String studentAge) {
        this.studentAge = studentAge;
    }

    public void setStudentClass(String studentClass) {
        this.studentClass = studentClass;
    }

    public String getStudentClass() {
        return studentClass;
    }

    public void setStudentPay(String studentPay) {
        this.studentPay = studentPay;
    }

    public String getStudentPay() {
        return studentPay;
    }
}
