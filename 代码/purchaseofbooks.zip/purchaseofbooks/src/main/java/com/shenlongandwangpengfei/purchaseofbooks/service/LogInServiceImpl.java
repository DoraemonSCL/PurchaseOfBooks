package com.shenlongandwangpengfei.purchaseofbooks.service;

import com.shenlongandwangpengfei.purchaseofbooks.dao.LogInDao;
import com.shenlongandwangpengfei.purchaseofbooks.entity.LogIn;
import com.shenlongandwangpengfei.purchaseofbooks.service.Impl.LogInService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LogInServiceImpl implements LogInService {
    @Autowired
    private LogInDao logInDao ;

    @Override
    public LogIn getLogIn() {
        return logInDao.getLogIn();
    }
}
