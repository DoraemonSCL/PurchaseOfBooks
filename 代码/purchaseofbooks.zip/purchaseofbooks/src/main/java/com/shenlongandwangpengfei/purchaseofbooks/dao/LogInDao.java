package com.shenlongandwangpengfei.purchaseofbooks.dao;

import com.shenlongandwangpengfei.purchaseofbooks.entity.LogIn;
import org.springframework.stereotype.Repository;

@Repository
public interface LogInDao {
    public LogIn getLogIn();

}
