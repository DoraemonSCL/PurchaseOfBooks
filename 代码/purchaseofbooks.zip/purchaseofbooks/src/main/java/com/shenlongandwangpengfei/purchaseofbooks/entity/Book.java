package com.shenlongandwangpengfei.purchaseofbooks.entity;

import org.apache.ibatis.type.Alias;

@Alias(value = "book")// MyBatis指定别名
public class Book {
    private String bookId ;
    private String bookName;
    private String bookPublish;
    private String bookData ;
    private String bookInfo;
    private String bookQuantity ;

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookPublish(String bookPublish) {
        this.bookPublish = bookPublish;
    }

    public String getBookPublish() {
        return bookPublish;
    }

    public void setBookData(String bookData) {
        this.bookData = bookData;
    }

    public String getBookData() {
        return bookData;
    }

    public void setBookInfo(String bookInfo) {
        this.bookInfo = bookInfo;
    }

    public String getBookInfo() {
        return bookInfo;
    }

    public void setBookQuantity(String bookQuantity) {
        this.bookQuantity = bookQuantity;
    }

    public String getBookQuantity() {
        return bookQuantity;
    }
}
