package com.shenlongandwangpengfei.purchaseofbooks.entity;

public class Teacher {
    private String teacherId;
    private String teacherName;
    private String teacherDepartment;
    private String teacherTitle;

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }

    public String getTeacherId() {
        return teacherId;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherDepartment(String teacherDepartment) {
        this.teacherDepartment = teacherDepartment;
    }

    public String getTeacherDepartment() {
        return teacherDepartment;
    }

    public void setTeacherTitle(String teacherTitle) {
        this.teacherTitle = teacherTitle;
    }

    public String getTeacherTitle() {
        return teacherTitle;
    }
}
