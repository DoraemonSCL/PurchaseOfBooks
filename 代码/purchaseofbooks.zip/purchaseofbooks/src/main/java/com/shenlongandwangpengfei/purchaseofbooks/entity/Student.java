package com.shenlongandwangpengfei.purchaseofbooks.entity;

import org.apache.ibatis.type.Alias;

@Alias(value = "student")// MyBatis指定别名
public class Student
{
    private Long id = null;
    private String userName = null;
    public Student()
    {

    }
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
