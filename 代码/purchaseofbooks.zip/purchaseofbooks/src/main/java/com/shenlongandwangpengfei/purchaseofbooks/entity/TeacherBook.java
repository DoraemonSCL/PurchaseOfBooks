package com.shenlongandwangpengfei.purchaseofbooks.entity;

public class TeacherBook {
    private String teacherId;
    private String bookId;
    private String teacherBookdata;

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }

    public String getTeacherId() {
        return teacherId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getBookId() {
        return bookId;
    }

    public void setTeacherBookdata(String teacherBookdata) {
        this.teacherBookdata = teacherBookdata;
    }

    public String getTeacherBookdata() {
        return teacherBookdata;
    }
}
