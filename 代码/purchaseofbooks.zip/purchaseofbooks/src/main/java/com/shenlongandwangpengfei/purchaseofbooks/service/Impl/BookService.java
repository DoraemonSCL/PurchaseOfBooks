package com.shenlongandwangpengfei.purchaseofbooks.service.Impl;

import com.shenlongandwangpengfei.purchaseofbooks.entity.Book;

public interface BookService {
     Book getBook();
}
