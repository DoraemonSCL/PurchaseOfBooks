package com.shenlongandwangpengfei.purchaseofbooks.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MyConfig  implements WebMvcConfigurer {
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/static/js/**").addResourceLocations("classpath:/js/");
        registry.addResourceHandler("/static/images/**").addResourceLocations("classpath:/images/");
        registry.addResourceHandler("/static/css/**").addResourceLocations("classpath:/css/");
        registry.addResourceHandler("/mapper/*").addResourceLocations("classpath:/mapper/");
        registry.addResourceHandler("/view/*").addResourceLocations("classpath:/view/");
        registry.addResourceHandler("/common/*").addResourceLocations("classpath:/common/");

    }
}
