package com.shenlongandwangpengfei.purchaseofbooks.service;

import com.shenlongandwangpengfei.purchaseofbooks.dao.BookDao;
import com.shenlongandwangpengfei.purchaseofbooks.entity.Book;
import com.shenlongandwangpengfei.purchaseofbooks.service.Impl.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookServiceImpl implements BookService {
    @Autowired
   private BookDao bookDao ;

    @Override
    public Book getBook() {
        return bookDao.getBook();
    }
}
