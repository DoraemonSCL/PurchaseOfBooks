package com.shenlongandwangpengfei.purchaseofbooks.controller;

import com.shenlongandwangpengfei.purchaseofbooks.entity.LogIn;
import com.shenlongandwangpengfei.purchaseofbooks.service.Impl.BookService;
import com.shenlongandwangpengfei.purchaseofbooks.service.Impl.LogInService;
import com.shenlongandwangpengfei.purchaseofbooks.service.Impl.StudentService;
import com.shenlongandwangpengfei.purchaseofbooks.service.LogInServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/purchaseofbooks")
public class LogInController
{
    @Autowired
    private LogInService logInService = null ;
    @Autowired
    private StudentService studentService = null;
    @Autowired
    private BookService bookService = null;

    @RequestMapping("")
    public String toLogin()
    {
        return "login" ;
//        return "test";
    }
//    @RequestMapping(value="/login")
//    @ResponseBody
//    public LogIn getLogIn(String username)
//    {
//        System.out.println(logInService.getLogIn(username));
//        return logInService.getLogIn(username);
//    }
    @RequestMapping(value="/login")
//    @ResponseBody
    public String login(HttpServletRequest req) {
//        public String login(String username, String password , HttpServletRequest req) {
//        System.out.println("直接参数名匹配获取:用户名---" + username);
//        System.out.println("直接参数名匹配获取:密码---" + password);
        System.out.println("HttpServletRequest获取:用户名---" + req.getParameter("username"));
        System.out.println("HttpServletRequest获取:密码---" + req.getParameter("password"));
//        测试学生数据表
        Long id = Long.valueOf(1);
        System.out.println(studentService.getStudent((id)).getUserName());
//        测试登录数据表
        String username = logInService.getLogIn().getUserName();
        String password = logInService.getLogIn().getPassword();
        System.out.println("账号："+username+"密码："+password);
//        测试图书表
        System.out.println("********" + bookService.getBook().getBookId());
//        连接数据库，验证成功后登录
        if (req.getParameter("username").equals(logInService.getLogIn().getUserName())&&req.getParameter("password").equals(logInService.getLogIn().getPassword()))
        {
            return "main";
        }
        else
        {
            return "login" ;
        }
    }





//    @RequestMapping("/login")
//    public ModelAndView login()
//    {
//        ModelAndView modelAndView = new ModelAndView();
//        modelAndView.setViewName("login");
//        return modelAndView ;
//    }
//    public String main(@RequestParam String username, @RequestParam String password, Model model)
//    {
////        if (username.equals("admin")&&password.equals("123456"))
////            return "main";
//
//        return  "login" ;
//    }


    @RequestMapping("/back")
    public String background()
    {
        return "back" ;
    }
    @RequestMapping("/main")
    public String main()
    {
        return "404" ;
    }

}
