package com.shenlongandwangpengfei.purchaseofbooks.service;

import com.shenlongandwangpengfei.purchaseofbooks.dao.StudentDao;
import com.shenlongandwangpengfei.purchaseofbooks.entity.Student;
import com.shenlongandwangpengfei.purchaseofbooks.service.Impl.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentServiceImpl implements StudentService {
    @Autowired
  private StudentDao studentDao;

    @Override
    public Student getStudent(Long id) {
        return studentDao.getStudent(id);
    }
}
