package com.shenlongandwangpengfei.purchaseofbooks.service.Impl;

import com.shenlongandwangpengfei.purchaseofbooks.entity.LogIn;

public interface LogInService {
    LogIn getLogIn();
}
